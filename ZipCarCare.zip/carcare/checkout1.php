<?php
// Retrieve form data
$name = $_POST['name'];
$mobileno = $_POST['mobileno'];
$address = $_POST['address'];
$emailid = $_POST['emailid'];

// Retrieve product details from local storage
$productDetails = json_decode($_POST['productDetails'], true);

// Database configuration
session_start();
$servername = "localhost:3344";
$username = "root";
$password = "";
$dbname = "carcare";


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert order details into the database
$sql = "INSERT INTO orders (name, mobileno, address, emailid) VALUES ('$name', '$mobileno', '$address', '$emailid')";

if ($conn->query($sql) === true) {
    $orderId = $conn->insert_id;

    // Insert product details into the database
    foreach ($productDetails as $product) {
        $productId = $product['id'];
        $title = $product['title'];
        $price = $product['price'];

        $sql = "INSERT INTO order_details (order_id, product_id, title, price) VALUES ('$orderId', '$productId', '$title', '$price')";
        $conn->query($sql);
    }

    echo "Order placed successfully!";

    // Redirect to order confirmation page
    header("Location: order_confirmation.html");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>