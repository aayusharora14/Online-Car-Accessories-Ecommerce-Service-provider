<?php
session_start();
$servername = "localhost:3306";
$username = "root";
$password = "";
$dbname = "carcare";
// Retrieve form data
$firstName = $_POST['firstname'];
$registration = $_POST['registration'];
$date = $_POST['date'];
$phone = $_POST['phone'];
$address = $_POST['address'];

// Database connection


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert data into the database
$sql = "INSERT INTO service (firstname, lastname, email, phone, address) VALUES ('$firstName', '$registration', '$date', '$phone', '$address')";

if ($conn->query($sql) === TRUE) {
    // Redirect to index.php after successful submission
    header("Location: index.php");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>